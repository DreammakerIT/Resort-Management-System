using System.Diagnostics;
using Resort.Models;
using Microsoft.AspNetCore.Mvc;


namespace LuxuryResort.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult TimHieuThem()
        {
            return View();
        }

        public IActionResult Dining()
        {
            return View();
        }

        public IActionResult Facilities()
        {
            return View();
        }

        public IActionResult Offers()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult RoomDetails()
        {
            return View();
        }

        public IActionResult PrivatePoolVilla()
        {
            return View();
        }

        public IActionResult PresidentialSuite()
        {
            return View();
        }

        public IActionResult BungalowGarden()
        {
            return View();
        }
    }
}
